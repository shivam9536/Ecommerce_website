from django.shortcuts import render
from django.views import View
from store.models.product import Product


class Cart(View):
    def get(self, request):
        cart = list(request.session.get('cart').keys())
        products = Product.get_all_products_by_ids(cart)
        return render(request, 'cart.html',{'products': products})

