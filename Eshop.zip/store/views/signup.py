from django.shortcuts import render,redirect
from store.models import UserData
from store.forms import SignUpForm
from django.contrib.auth.hashers import make_password,check_password
from django.views import View

class SignUp(View):
    def get(self, request):
        form = SignUpForm()
        return render(request, 'signup.html', {'form': form})

    def post(self, request):
        form = SignUpForm(request.POST)
        email = request.POST.get('email')
        customer = UserData.get_userdata_by_email(email)
        error_message = 'email already exists enter new email'
        if customer:
            form = SignUpForm()
            return render(request, 'signup.html', {'error': error_message, 'form': form})
        else:
            if form.is_valid():
                user = form.save(commit=True)
                user.password = make_password(user.password)
                user.save()
                # return HttpResponse("user saved")
            return redirect('homepage')