from django.shortcuts import render, redirect
from store.models import Product
from store.models.category import Category
from django.views import View

class Index(View):
    def post(self,request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            if cart.get(product):
                if remove:
                    if cart.get(product) ==1:
                        cart.pop(product)
                    else:
                        cart[product]-=1
                else:
                    cart[product]+=1
            else:
                cart[product]=1
        else:
            cart[product]=1
        request.session['cart'] = cart
        print(request.session.get('cart'))
        return redirect('homepage')


    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart']={}

        products = None
        categories = Category.get_all_categories()
        categoryID = request.GET.get('category')
        if categoryID:
            products = Product.get_all_products_by_id(categoryID)
        else:
            products = Product.get_all_products()

        my_dict = {'products': products, 'categories': categories}
        print('you are:', request.session.get('customer'))
        return render(request, 'store/index.html', my_dict)



