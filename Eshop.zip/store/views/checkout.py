from django.shortcuts import redirect
from django.views import View
from store.models import Product, Order, UserData


class CheckOut(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_all_products_by_ids(list(cart.keys()))
        print(address,phone,customer,products)

        for product in products:
            order = Order(customer = UserData(customer),
                          product = product,
                          price = product.price,
                          address = address,
                          phone = phone,
                          quantity = cart.get(str(product.id)))
            order.placeOrder()
        request.session['cart']={}
        return redirect('cart')



