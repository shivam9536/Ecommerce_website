from django.urls import path
from store.views.index import Index
from store.views.login import Login,logout
from store.views.signup import SignUp
from store.views.cart import Cart
from store.views.checkout import CheckOut
from store.views.orders import Orders
from store.middlewares.auth import auth_middleware
urlpatterns = [
    path('',Index.as_view(), name='homepage'),
    path('signup/',SignUp.as_view(), name = 'signuppage'),
    path('login/',Login.as_view(),name='login'),
    path('logout/',logout,name='logout'),
    path('cart',Cart.as_view(),name='cart'),
    path('checkout',CheckOut.as_view(),name='checkout'),
    path('orders',auth_middleware(Orders.as_view()),name='orders')

]
