from django.contrib import admin
from store.models import Product
from store.models import Category
from store.models import UserData
from store.models import Order

# Register your models here.
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name','price','category']

class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name']

class UserdataAdmin(admin.ModelAdmin):
    list_display = ['email']


admin.site.register(Product,ProductAdmin)
admin.site.register(Category,CategoryAdmin)
admin.site.register(UserData,UserdataAdmin)
admin.site.register(Order)