from django import forms
from store.models import UserData

class SignUpForm(forms.ModelForm):
    class Meta:
        model = UserData
        fields = '__all__'

