from django.db import models

class UserData(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone = models.CharField(max_length=15,null=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=500)


    @staticmethod
    def get_userdata_by_email(email):
        try:
            return UserData.objects.get(email = email)
        except:
            return False


    def is_Exits(self):
        if UserData.objects.get(email=self.email):
            return True
        return False


